#ifndef RANGE_H_
#define RANGE_H_

#include <iterator>

class Range {
 public:
  class Iterator {
   public:
    using iterator_category = std::input_iterator_tag;
    using value_type = int;
    using difference_type = int;
    using pointer = const int*;
    using reference = const int&;

    Iterator(int current, int step, int end);

    int operator*() const;
    Iterator& operator++();
    bool operator!=(const Iterator& other) const;

   private:
    int current_;
    int step_;
    int end_;
  };

  Range(int end);
  Range(int begin, int end);
  Range(int begin, int end, int step);

  Iterator begin() const;
  Iterator end() const;

 private:
  int begin_;
  int end_;
  int step_;
};

#endif  // RANGE_H_
