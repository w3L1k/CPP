#include "range.h"

Range::Iterator::Iterator(int current, int step, int end)
    : current_(current), step_(step), end_(end) {}

int Range::Iterator::operator*() const {
  return current_;
}

Range::Iterator& Range::Iterator::operator++() {
  current_ += step_;
  return *this;
}

bool Range::Iterator::operator!=(const Iterator& other) const {
  if (step_ > 0) {
    return current_ < other.current_;
  }
  return current_ > other.current_;
}

Range::Range(int end) : begin_(0), end_(end), step_(1) {}

Range::Range(int begin, int end) : begin_(begin), end_(end), step_(1) {}

Range::Range(int begin, int end, int step)
    : begin_(begin), end_(end), step_(step) {}

Range::Iterator Range::begin() const {
  return Iterator(begin_, step_, end_);
}

Range::Iterator Range::end() const {
  return Iterator(end_, step_, end_);
}
