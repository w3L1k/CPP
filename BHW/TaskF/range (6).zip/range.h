#ifndef RANGE_H
#define RANGE_H

class RangeIterator {
private:
  int value_;
  int step_;

public:
  explicit RangeIterator(int start, int step) : value_(start), step_(step) {}

  int operator*() const {
    return value_;
  }

  RangeIterator& operator++() {
      value_ += step_;
      return *this;
  }

  bool operator!=(const RangeIterator& other) const {
    if (step_ > 0) {
      return value_ < other.value_;
    } else if (step_ < 0) {
      return value_ > other.value_;
    }
    return false;
  }
};

class Range {
private:
  int start_;
  int finish_;
  int step_;

public:
  explicit Range(int finish) : start_(0), finish_(finish), step_(1) {}
  Range(int start, int finish) : start_(start), finish_(finish), step_(1) {}
  Range(int start, int finish, int step) : start_(start), finish_(finish), step_(step) {}

  RangeIterator begin() const {
    return RangeIterator(start_, step_);
  }

  RangeIterator end() const {
    return RangeIterator(finish_, step_);
  }
};

#endif
