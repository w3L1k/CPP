#include "range.h"

RangeIterator::RangeIterator(int current, int step)
    : current_(current), step_(step) {}

int RangeIterator::operator*() const {
  return current_;
}

RangeIterator& RangeIterator::operator++() {
  current_ += step_;
  return *this;
}

bool RangeIterator::operator!=(const RangeIterator& other) const {
  return step_ > 0 ? current_ < other.current_ : current_ > other.current_;
}

Range::Range(int end)
    : begin_(0), end_(end), step_(1) {}

Range::Range(int begin, int end)
    : begin_(begin), end_(end), step_(1) {}

Range::Range(int begin, int end, int step)
    : begin_(begin), end_(end), step_(step) {}

RangeIterator Range::begin() const {
  if ((step_ > 0 && begin_ >= end_) || (step_ < 0 && begin_ <= end_) || step_ == 0) {
    return RangeIterator(0, step_);
  }
  return RangeIterator(begin_, step_);
}

RangeIterator Range::end() const {
  return RangeIterator(end_, step_);
}

#ifdef REVERSE_RANGE_IMPLEMENTED

Range::ReverseRangeIterator::ReverseRangeIterator(int current, int step)
    : current_(current), step_(step) {}

int Range::ReverseRangeIterator::operator*() const {
  return current_;
}

Range::ReverseRangeIterator& Range::ReverseRangeIterator::operator++() {
  current_ -= step_;
  return *this;
}

bool Range::ReverseRangeIterator::operator!=(const ReverseRangeIterator& other) const {
  return step_ > 0 ? current_ >= other.current_ : current_ <= other.current_;
}

Range::ReverseRangeIterator Range::rbegin() const {
  if ((step_ > 0 && begin_ >= end_) || (step_ < 0 && begin_ <= end_) || step_ == 0) {
    return ReverseRangeIterator(0, step_);
  }

  int count = (end_ - begin_ + step_ - 1) / step_;
  int last_value = begin_ + (count - 1) * step_;
  return ReverseRangeIterator(last_value, step_);
}

Range::ReverseRangeIterator Range::rend() const {
  return ReverseRangeIterator(begin_ - step_, step_);
}

#endif  // REVERSE_RANGE_IMPLEMENTED
