#include "big_integer.h"

BigInteger::BigInteger() : is_negative_(false) {}

BigInteger::BigInteger(int value) : is_negative_(value < 0) {
  if (value != 0) {
    int64_t v = value;
    if (v < 0) {
       v = -v;
    }
    while (v > 0) {
      digits_.push_back(static_cast<int>(v % kBASE));
      v /= kBASE;
    }
  }
}

BigInteger::BigInteger(int64_t value) : is_negative_(value < 0) {
  if (value != 0) {
    if (value < 0) {
      value = -value;
    }
    while (value > 0) {
      digits_.push_back(static_cast<int>(value % kBASE));
      value /= kBASE;
    }
  }
}

BigInteger::BigInteger(const char* s) { FromString(s); }
BigInteger::BigInteger(const std::string& s) { FromString(s); }

BigInteger::BigInteger(BigInteger&& other) noexcept
  : digits_(std::move(other.digits_)), is_negative_(other.is_negative_) {
  other.is_negative_ = false;
}

bool BigInteger::IsNegative() const {
  return is_negative_;
}

BigInteger BigInteger::operator+() const {
  return *this;
}

BigInteger BigInteger::operator-() const {
  BigInteger r = *this;
  if (!digits_.empty()) {
    r.is_negative_ = !r.is_negative_;
  }
  return r;
}

BigInteger& BigInteger::operator+=(const BigInteger& other) {
  if (is_negative_ == other.is_negative_) {
    int carry = 0;
    size_t n = std::max(digits_.size(), other.digits_.size());
    digits_.resize(n, 0);
    for (size_t i = 0; i < n || carry; ++i) {
      if (i == digits_.size()) {
        digits_.push_back(0);
      }
      digits_[i] += carry + (i < other.digits_.size() ? other.digits_[i] : 0);
      carry = digits_[i] >= kBASE;
      if (carry) {
        digits_[i] -= kBASE;
      }
      if (digits_[i] < 0 || digits_[i] >= kBASE) {
        throw BigIntegerOverflow();
      }
    }
  } else {
    *this -= -other;
  }
  Trim();
  return *this;
}

BigInteger& BigInteger::operator-=(const BigInteger& other) {
  if (is_negative_ == other.is_negative_) {
    if ( (*this).Abs() >= other.Abs() ) {
      int carry = 0;
      for (size_t i = 0; i < other.digits_.size() || carry; ++i) {
        if (i == digits_.size()) {
          digits_.push_back(0);
        }
        digits_[i] -= carry + (i < other.digits_.size() ? other.digits_[i] : 0);
        carry = digits_[i] < 0;
        if (carry) {
          digits_[i] += kBASE;
        }
        if (digits_[i] < 0 || digits_[i] >= kBASE) {
          throw BigIntegerOverflow();
        }
      }
      Trim();
    } else {
      *this = -(other - *this);
    }
  } else {
    *this += -other;
  }
  return *this;
}

BigInteger& BigInteger::operator*=(const BigInteger& other) {
  std::vector<uint64_t> res(digits_.size() + other.digits_.size(), 0);
  for (size_t i = 0; i < digits_.size(); ++i) {
    for (size_t j = 0; j < other.digits_.size(); ++j) {
      res[i + j] += static_cast<uint64_t>(digits_[i]) * other.digits_[j];
      if (res[i + j] >= static_cast<uint64_t>(kBASE)) {
        res[i + j + 1] += res[i + j] / kBASE;
        res[i + j] %= kBASE;
      }
    }
  }
  digits_.assign(res.begin(), res.end());
  is_negative_ = is_negative_ != other.is_negative_;
  for (int d : digits_) {
    if (d < 0 || d >= kBASE) {
      throw BigIntegerOverflow();
    }
  }
  Trim();
  return *this;
}

BigInteger operator+(BigInteger lhs, const BigInteger& rhs) {
  return lhs += rhs;
}
BigInteger operator-(BigInteger lhs, const BigInteger& rhs) {
  return lhs -= rhs;
}
BigInteger operator*(BigInteger lhs, const BigInteger& rhs) {
  return lhs *= rhs;
}

BigInteger& BigInteger::operator++() {
  return *this += BigInteger(1);
}
BigInteger BigInteger::operator++(int) {
  BigInteger tmp = *this;
  ++*this;
  return tmp;
}
BigInteger& BigInteger::operator--() {
  return *this -= BigInteger(1);
}
BigInteger BigInteger::operator--(int) {
  BigInteger tmp = *this;
  --*this;
  return tmp;
}

BigInteger::operator bool() const {
  return !digits_.empty();
}

bool operator==(const BigInteger& a, const BigInteger& b) {
  return a.is_negative_ == b.is_negative_ && a.digits_ == b.digits_;
}
bool operator!=(const BigInteger& a, const BigInteger& b) {
  return !(a == b);
}
bool operator<(const BigInteger& a, const BigInteger& b) {
  if (a.is_negative_ != b.is_negative_) {
    return a.is_negative_;
  }
  if (a.digits_.size() != b.digits_.size()) {
    return a.digits_.size() * (a.is_negative_ ? -1 : 1)
         < b.digits_.size() * (b.is_negative_ ? -1 : 1);
  }
  for (int i =  static_cast<int>(a.digits_.size()) - 1; i >= 0; --i) {
    if (a.digits_[i] != b.digits_[i]) {
      return a.digits_[i] * (a.is_negative_ ? -1 : 1)
           < b.digits_[i] * (b.is_negative_ ? -1 : 1);
    }
  }
  return false;
}
bool operator<=(const BigInteger& a, const BigInteger& b) {
  return !(b < a);
}
bool operator>(const BigInteger& a, const BigInteger& b) {
  return b < a;
}
bool operator>=(const BigInteger& a, const BigInteger& b) {
  return !(a < b);
}

std::ostream& operator<<(std::ostream& os, const BigInteger& v) {
  if (v.is_negative_) {
    os << '-';
  }
  if (v.digits_.empty()) {
    os << '0';
  } else {
    os << v.digits_.back();
    for (int i = static_cast<int>(v.digits_.size()) - 2; i >= 0; --i) {
      os << std::setw(BigInteger::kBaseDigits)
         << std::setfill('0') << v.digits_[i];
    }
  }
  return os;
}

std::istream& operator>>(std::istream& is, BigInteger& v) {
  std::string s;
  is >> s;
  v = BigInteger(s);
  return is;
}

void BigInteger::Trim() {
  while (!digits_.empty() && digits_.back() == 0) {
    digits_.pop_back();
  }
  if (digits_.empty()) {
    is_negative_ = false;
  }
}

void BigInteger::FromString(const std::string& s) {
  is_negative_ = false;
  digits_.clear();
  int pos = 0;
  if (s[0] == '-' || s[0] == '+') {
    is_negative_ = (s[0] == '-');
    pos = 1;
  }
  for (int i = static_cast<int>(s.size()) - 1; i >= pos; i -= kBaseDigits) {
    int x = 0;
    int l = std::max(pos, i - kBaseDigits + 1);
    for (int j = l; j <= i; ++j) {
      if (x > (std::numeric_limits<int>::max() - (s[j] - '0')) / 10)
        throw BigIntegerOverflow();
      x = x * 10 + (s[j] - '0');
    }
    if (x < 0 || x >= kBASE) throw BigIntegerOverflow();
    digits_.push_back(x);
  }
  Trim();
}

