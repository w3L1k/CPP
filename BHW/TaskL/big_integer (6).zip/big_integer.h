#pragma once

#include <iostream>
#include <vector>
#include <string>
#include <stdexcept>
#include <iomanip>
#include <algorithm>
#include <cstdint>
#include <limits>

class BigIntegerOverflow : public std::runtime_error {
 public:
  BigIntegerOverflow() : std::runtime_error("BigInteger overflow") {}
};

class BigInteger {
 private:
  std::vector<int> digits_;
  bool is_negative_;

  static const int kBASE = 10000;
  static const int kBaseDigits = 4;

  void Trim();
  void FromString(const std::string& s);

 public:
  BigInteger();
  BigInteger(int  value); // NOLINT
  BigInteger(int64_t value); // NOLINT
  explicit BigInteger(const char* value);
  explicit BigInteger(const std::string& value);

  BigInteger(const BigInteger& other) = default;
  BigInteger(BigInteger&& other) noexcept;

  bool IsNegative() const;
  BigInteger Abs() const;

  BigInteger operator+() const;
  BigInteger operator-() const;

  BigInteger& operator+=(const BigInteger& other);
  BigInteger& operator-=(const BigInteger& other);
  BigInteger& operator*=(const BigInteger& other);

  BigInteger& operator=(const BigInteger& other) = default;
  BigInteger& operator=(BigInteger&& other) noexcept;

  friend BigInteger operator+(BigInteger lhs, const BigInteger& rhs);
  friend BigInteger operator-(BigInteger lhs, const BigInteger& rhs);
  friend BigInteger operator*(BigInteger lhs, const BigInteger& rhs);

  BigInteger& operator++();
  BigInteger operator++(int);
  BigInteger& operator--();
  BigInteger operator--(int);

  explicit operator bool() const;

  friend bool operator==(const BigInteger& a, const BigInteger& b);
  friend bool operator!=(const BigInteger& a, const BigInteger& b);
  friend bool operator<(const BigInteger& a, const BigInteger& b);
  friend bool operator<=(const BigInteger& a, const BigInteger& b);
  friend bool operator>(const BigInteger& a, const BigInteger& b);
  friend bool operator>=(const BigInteger& a, const BigInteger& b);

  friend std::ostream& operator<<(std::ostream& os, const BigInteger& value);
  friend std::istream& operator>>(std::istream& is, BigInteger& value);
};
