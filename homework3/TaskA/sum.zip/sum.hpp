#pragma once
#include <cstdint>

int64_t Sum(int x, int y);
