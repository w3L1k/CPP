#include "sum.hpp"
#include <cstdint>

int64_t Sum(int x, int y) {
  return static_cast<int64_t>(x) + static_cast<int64_t>(y);
}
